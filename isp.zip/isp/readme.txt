Run isp.bat from DOS.
This uses elements installed with WinAVR to run the USBTiny AVR and load an ATTiny85 with a bootloader. The ATTiny85 can then be used to make an ATTiny85 Arduino or PaperDuino.
Mike Druiven
Feb 5 2018